// PREPARED ONLY. No run/import authorized yet. No dependencies in this driver.
import http from 'node:http';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
const root=path.dirname(fileURLToPath(import.meta.url));
const response={id:'synthetic-completion',created:0,model:'synthetic-model',choices:[{message:{role:'assistant',content:'synthetic-ok'},finish_reason:'stop'}],usage:{prompt_tokens:1,completion_tokens:1,total_tokens:2}};
const cases=[
 {id:'camel-null',extra:{providerOptions:{example:{reasoningEffort:null}}},base:'validation',head:'null'},
 {id:'raw-null',extra:{providerOptions:{example:{reasoning_effort:null}}},base:'absent',head:'null'},
 {id:'absent',extra:{},base:'absent',head:'absent'},
 {id:'low',extra:{providerOptions:{example:{reasoningEffort:'low'}}},base:'low',head:'low'},
 {id:'null-over-medium',extra:{reasoning:'medium',providerOptions:{example:{reasoningEffort:null}}},base:'validation',head:'null'},
];
let requests=[],activeCase=null,server,origin,wholeTimer,observations=0;
const emit=x=>console.log(JSON.stringify(x));
const serializeError=e=>({name:e?.name,message:e?.message,stack:e?.stack,cause:e?.cause?{name:e.cause.name,message:e.cause.message,issues:e.cause.issues}:undefined});
const nativeFetch=globalThis.fetch;
// Guard both configured and global fetch; reject redirects and all non-exact URLs.
const guardedFetch=(input,options={})=>{
 if(activeCase===null) throw Error('Fetch outside active case');
 const url=typeof input==='string'?input:input instanceof URL?input.href:input.url;
 if(url!==`${origin}/chat/completions`) throw Error('Forbidden request URL');
 assert.equal(options.method,'POST');
 const headers=new Headers(options.headers);
 assert.equal(headers.has('authorization'),false);assert.equal(headers.has('cookie'),false);
 return nativeFetch(input,{...options,redirect:'error'});
};
function expectedValidation(error) {
 // Exact statically inspected wrapper. Nested cause is preserved, not guessed.
 return error?.name==='AI_InvalidArgumentError' && error?.argument==='providerOptions' && error?.message==='invalid example provider options';
}
async function runCase(Class,variant,c) {
 try {
 const before=requests.length; activeCase={variant,case:c.id};
 const abort=new AbortController();let timer;
 let result,error;
 try {
  const model=new Class('synthetic-model',{provider:'example',headers:()=>({}),url:()=>`${origin}/chat/completions`,fetch:guardedFetch});
  const options={prompt:[{role:'user',content:[{type:'text',text:'synthetic prompt'}]}],...structuredClone(c.extra),abortSignal:abort.signal};
  result=await Promise.race([model.doGenerate(options),new Promise((_,reject)=>{timer=setTimeout(()=>{abort.abort();reject(Error('Per-call 5s timeout'));},5000);})]);
 } catch(e){error=e;} finally{clearTimeout(timer);abort.abort();}
 const seen=requests.slice(before); const expected=c[variant];
 const observed={variant,case:c.id,expected,httpCount:seen.length,requests:seen,error:error?serializeError(error):undefined};
 emit(observed);observations++;
 if(expected==='validation') {
  assert.equal(seen.length,0,'Expected pre-HTTP option validation');
  if(!expectedValidation(error)) throw Error('INCONCLUSIVE: unrecognized baseline error signature');
  return;
 }
 if(error) throw Error('INCONCLUSIVE: class/transport/response error',{cause:error});
 assert.equal(seen.length,1); assert.ok(result.content.some(x=>x.type==='text'&&x.text==='synthetic-ok'),'Response parse control');
 const body=seen[0].body;assert.equal(body.model,'synthetic-model');assert.deepEqual(body.messages,[{role:'user',content:'synthetic prompt'}]);
 assert.equal(Object.hasOwn(body,'reasoning_effort'),expected!=='absent','own wire key');
 if(expected==='null') assert.equal(body.reasoning_effort,null,'strict null');
 if(expected==='low') assert.equal(body.reasoning_effort,'low','strict string');
 } finally { activeCase=null; }
}
try {
 assert.equal(process.version,'v26.11.1','Runtime drift');
 wholeTimer=setTimeout(()=>{emit({status:'INCONCLUSIVE',error:'Whole comparison 30s timeout'});server?.closeAllConnections();server?.close();process.exit(2);},30000);
 globalThis.fetch=guardedFetch;
 server=http.createServer(async(req,res)=>{
  try {
   assert.equal(req.method,'POST');assert.equal(req.url,'/chat/completions');
   let text='';for await(const chunk of req){text+=chunk;if(Buffer.byteLength(text)>10240)throw Error('Request size bound');}
   requests.push({...activeCase,body:JSON.parse(text)});
   res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify(response));
  }catch(e){emit({status:'INCONCLUSIVE',serverError:serializeError(e)});res.writeHead(400);res.end('{}');}
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
 origin=`http://127.0.0.1:${server.address().port}`;
 emit({runtime:process.version,platform:process.platform,arch:process.arch,bounds:{perCallMs:5000,wholeMs:30000},response,prompt:'synthetic prompt'});
 for(const variant of ['base','head']) {
  const module=await import(new URL(`./compiled/${variant}/chat/openai-compatible-chat-language-model.js`,import.meta.url));
  for(const c of cases)await runCase(module.OpenAICompatibleChatLanguageModel,variant,c);
 }
 assert.equal(observations,10,'Exactly ten case observations');
 assert.equal(requests.length,8,'Exactly eight HTTP requests');
 emit({status:'PASS',scope:'PR-base versus PR-head dependency-conditioned loopback serialization only',requests:requests.length});
}catch(error){emit({status:'INCONCLUSIVE_OR_ASSERTION_FAILURE',error:serializeError(error)});process.exitCode=2;}
finally{globalThis.fetch=nativeFetch;clearTimeout(wholeTimer);if(server){server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}}
