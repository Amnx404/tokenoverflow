import { UnsupportedFunctionalityError, } from '@ai-sdk/provider';
export function prepareTools({ tools, toolChoice, }) {
    // when the tools array is empty, change it to undefined to prevent errors:
    tools = tools?.length ? tools : undefined;
    const toolWarnings = [];
    if (tools == null) {
        return { tools: undefined, toolChoice: undefined, toolWarnings };
    }
    const openaiCompatTools = [];
    for (const tool of tools) {
        if (tool.type === 'provider') {
            toolWarnings.push({
                type: 'unsupported',
                feature: `provider-defined tool ${tool.id}`,
            });
        }
        else {
            openaiCompatTools.push({
                type: 'function',
                function: {
                    name: tool.name,
                    description: tool.description,
                    parameters: tool.inputSchema,
                    ...(tool.strict != null ? { strict: tool.strict } : {}),
                },
            });
        }
    }
    if (toolChoice == null) {
        return { tools: openaiCompatTools, toolChoice: undefined, toolWarnings };
    }
    const type = toolChoice.type;
    switch (type) {
        case 'auto':
        case 'none':
        case 'required':
            return { tools: openaiCompatTools, toolChoice: type, toolWarnings };
        case 'tool':
            return {
                tools: openaiCompatTools,
                toolChoice: {
                    type: 'function',
                    function: { name: toolChoice.toolName },
                },
                toolWarnings,
            };
        default: {
            const _exhaustiveCheck = type;
            throw new UnsupportedFunctionalityError({
                functionality: `tool choice type: ${_exhaustiveCheck}`,
            });
        }
    }
}
